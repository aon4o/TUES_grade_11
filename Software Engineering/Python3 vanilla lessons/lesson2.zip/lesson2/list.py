assorted_list = [True, False, 1, 1.1, 1+2j, 'Learn', b'Python']
first_element = assorted_list[0]
print(first_element)
print(assorted_list)
for item in assorted_list:
	print(type(item))