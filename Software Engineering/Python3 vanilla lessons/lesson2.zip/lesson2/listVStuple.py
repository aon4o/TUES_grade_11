list_num = [1,2,3,4]
tup_num = (1,2,3,4)
print(list_num)
print(tup_num)
type(list_num)
type(tup_num)
list_num[2] = 5
print(list_num)
# uncomment this in the end 
# tup_num[2] = 5