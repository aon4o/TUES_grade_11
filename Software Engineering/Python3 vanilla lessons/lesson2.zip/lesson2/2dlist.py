nested = [[1,1,1], [2,2,2], [3,3,3]]
for items in nested:
	for item in items:
		print(item, end=' ')