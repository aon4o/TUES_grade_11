def div(arg1, arg2):
    if arg2 == 0:
        return -1
    else:
        return arg1 / arg2


def avg(my_list):
    list_sum = 0
    count = 0
    for item in my_list:
        list_sum += item
        count += 1
    return div(list_sum, count)


def test_avg():
    result1 = div(2, 1)
    print(result1, 'is 2 divided on 1')

    list1 = [1, 2, 3, 4, 5]
    print(avg(list1), ' is list 1 average')
    list2 = [-4, -1, 2]
    print(avg(list2), ' is list 2 average')


def test_avg_empty_list():
    list3 = []
    avg_result = avg(list3)
    if avg_result == -1:
        print("Empty list failed!")


def test_avg_empty_list_without_error_check():
    list3 = []
    print(avg(list3), ' is list 3 average')


test_avg()
test_avg_empty_list()
test_avg_empty_list_without_error_check()
