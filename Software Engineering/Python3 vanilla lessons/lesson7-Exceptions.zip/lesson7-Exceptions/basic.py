try:
    fob = open("test", "r")
    fob.write("This is my test file for exception handling!!")
except IOError:
    print("Error: can\'t find the file or read data")
else:
    print("Write operation is performed successfully on the file")
finally:
    fob.close()
    print("File closed")
