class DivideByZeroError(Exception):
    """Base class for other exceptions"""
    def __init__(self, message):
        self.message = message


def div(arg1, arg2):
    if arg2 == 0:
        error_message = "Can not divide " + str(arg1) + " by zero!"
        raise DivideByZeroError(error_message)
    else:
        return arg1 / arg2


def avg(my_list):
    list_sum = 0
    count = 0
    for item in my_list:
        list_sum += item
        count += 1
    return div(list_sum, count)


def test_avg():
    result1 = div(2, 1)
    print(result1, 'is 2 divided on 1')

    list1 = [1, 2, 3, 4, 5]
    print(avg(list1), ' is list 1 average')
    list2 = [-4, -1, 2]
    print(avg(list2), ' is list 2 average')


def test_avg_empty_list():
    try:
        list3 = []
        print(avg(list3), ' is list 3 average')
    except Exception as err:
        print("Empty list failed. Message: " + err.message)


def test_avg_empty_list_without_exception_check():
    list3 = []
    print(avg(list3), ' is list 3 average')


test_avg()
test_avg_empty_list()
# Uncomment the bellow line for test
# test_avg_empty_list_without_exception_check()
