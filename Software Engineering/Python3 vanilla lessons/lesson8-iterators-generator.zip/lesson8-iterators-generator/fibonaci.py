# Demonstrate Python Generator Function
def fibonacci(xterms):
    result = [];
    # first two terms
    x1 = 0
    x2 = 1
    count = 0

    if xterms <= 0:
        print("Please provide a +ve integer")
    elif xterms == 1:
        print("Fibonacci seq up to", xterms, ":")
        print(x1)
    else:
        while count < xterms:
            xth = x1 + x2
            x1 = x2
            x2 = xth
            count += 1
            result.append(xth)

    return result


fib = fibonacci(5)

print("Fibonacci  sec: ", fib)
