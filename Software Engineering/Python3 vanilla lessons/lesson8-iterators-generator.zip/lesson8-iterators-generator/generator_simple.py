def reverse(data):
    for index in range(len(data) - 1, -1, -1):
        yield data[index]


reversed_string = reverse("abc")


print(next(reversed_string))
print(next(reversed_string))
print(next(reversed_string))
