import unittest

from students import Students


class TestStudent(unittest.TestCase):
	def test_add_student(self):
		students = Students()
		self.assertIsNone(students.add_student
		                  (1, "Alex", "Sofia", "Street Something", 60),
		                  "ERROR: could not add a student")
		with self.assertRaises(ValueError):
			students.add_student(1, "Alex", "Sofia", "Street Something", 60)

	def test_get_name(self):
		students = Students()
		students.add_student(1, "Alex", "Sofia", "Street Something", 60)
		self.assertEqual(students.get_name(1), "Alex",
		                 "ERROR: could not get name")
		with self.assertRaises(KeyError):
			students.get_name(2)

	def test_set_name(self):
		students = Students()
		students.add_student(1, "Alex", "Sofia", "Street Something", 60)
		self.assertIsNone(students.set_name(1, "asd"),
		                 "ERROR: could not set name")
		with self.assertRaises(KeyError):
			students.set_name(10, "asd")

	def test_get_address(self):
		students = Students()
		students.add_student(1, "Alex", "Sofia", "Street Something", 60)
		self.assertEqual(students.get_address(1),
		                 ["Sofia", "Street Something", 60],
		                 "ERROR: could not get address")
		with self.assertRaises(KeyError):
			students.get_address(2)

	def test_set_address(self):
		students = Students()
		students.add_student(1, "Alex", "Sofia", "Street Something", 60)
		self.assertIsNone(students.set_address(1, "asd", "asd", 1),
		                 "ERROR: could not set address")
		with self.assertRaises(KeyError):
			students.set_address(2, "asd", "asd", 10)

	def test_add_mark(self):
		students = Students()
		students.add_student(1, "Alex", "Sofia", "Street Something", 60)

		self.assertIsNone(students.add_mark(1, "Math", 6),
		                 "ERROR: could not add mark")

		with self.assertRaises(KeyError):
			students.add_mark(2, "Math", 6)

	def test_get_marks(self):
		students = Students()
		students.add_student(1, "Alex", "Sofia", "Street Something", 60)

		students.add_mark(1, "Math", 6)
		students.add_mark(1, "Math", 5)

		self.assertEqual(students.get_marks(1, "Math"), [6, 5],
		                 "ERROR: could not get marks")

		with self.assertRaises(KeyError):
			students.get_marks(2, "Math")
		with self.assertRaises(KeyError):
			students.get_marks(1, "Python")

	def test_get_average(self):
		students = Students()
		students.add_student(1, "Alex", "Sofia", "Street Something", 60)

		students.add_mark(1, "Math", 6)

		self.assertEqual(students.get_average(1, "Math"), 6,
		                 "ERROR: could not get average")
		with self.assertRaises(KeyError):
			students.get_average(2, "Math")
		with self.assertRaises(KeyError):
			students.get_average(1, "Python")

