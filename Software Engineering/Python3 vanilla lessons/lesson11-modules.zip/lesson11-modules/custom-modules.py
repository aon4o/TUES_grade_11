import factorial_definition as fact_lib

result = fact_lib.factorial(5)
print("factorial : ", result)
print("Pi : ", fact_lib.Pi)