class Taxi:

    def __init__(self, model, capacity, variant):
        self.__model = model      # __model is private to Taxi class
        self.__capacity = capacity
        self.__variant = variant

    def get_model(self):          # get_model() is accessible outside the class
        return self.__model

    def get_capacity(self):         # get_capacity() function is accessible to class Vehicle
        return self.__capacity

    def set_capacity(self, capacity):  # set_capacity() is accessible outside the class
        self.__capacity = capacity

    def get_variant(self):         # get_variant() function is accessible to class Vehicle
        return self.__variant

    def set_variant(self, variant):  # set_variant() is accessible outside the class
        self.__variant = variant


class Vehicle(Taxi):

    def __init__(self, model, capacity, variant, color):
        # call parent constructor to set model and color  
        super().__init__(model, capacity, variant)
        self.__color = color

    def vehicle_info(self):
        return self.get_model() + " " + self.get_variant() + " in " + \
               self.__color + " with " + self.get_capacity() + " seats"

# In method getInfo we can call get_model(), getCapacity() as they are
# accessible in the child class through inheritance


v1 = Vehicle("i20 Active", "4", "SX", "Bronze")
print(v1.vehicle_info())
print(v1.get_model())  # Vehicle has no method getModel() but it is accessible via Vehicle class

v2 = Vehicle("Fortuner", "7", "MT2755", "White")
print(v2.vehicle_info())
print(v2.get_model())  # Vehicle has no method getModel() but it is accessible via Vehicle class
