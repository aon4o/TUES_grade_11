class MarkBook:
    __grades = {}

    def add_mark(self, subject, mark):
        if subject not in self.__grades:
            self.__grades[subject] = list([])            
        self.__grades[subject].append(mark)
        
    def get_marks(self, subject):
        self.__grades[subject]
        
    def get_average(self, subject):
        return sum(self.__grades[subject]) / len(self.__grades[subject])
      

class Student:    
    def __init__(self, name, number):
        self.__name = name
        self.__number = number
        self.__markBook = MarkBook()

    def add_mark(self, subject, mark):
        self.__markBook.add_mark(subject, mark)

    def get_average(self, subject):
        return self.__markBook.get_average(subject)
        
    def get_mame(self) :
        return self.__name
        
    def get_number(self):
        return self.__number


student = Student("Stoyan Hristov", 22)
student.add_mark("TP", 2)
student.add_mark("TP", 4)
print("Average mark:", student.get_average("TP"), "\n")
