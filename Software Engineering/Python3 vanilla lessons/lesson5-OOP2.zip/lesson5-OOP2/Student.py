class Student:    
    def __init__(self, name, number):
        self.__name = name
        self.__number = number
        self.__grades = {}

    def add_mark(self, subject, mark):
        if subject not in self.__grades:
            self.__grades[subject] = list([])
            
        self.__grades[subject].append(mark)

    def get_average(self, subject):
        print(self.__grades[subject])
        return sum(self.__grades[subject]) / len(self.__grades[subject])
        
    def get_name(self) :
        return self.__name
        
    def get_number(self):
        return self.__number


student = Student("Stoyan Hristov", 22)
student.add_mark("TP", 2)
student.add_mark("TP", 4)
print("Average mark:", student.get_average("TP"), "\n")
