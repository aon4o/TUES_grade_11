# This is usual one line comment
def theFunction():
    '''
This function demonstrate the use of docstring in Python.
    '''
    print("Python docstrings are not comments.")

print("\nJust printing the docstring value...")
print(theFunction.__doc__)
