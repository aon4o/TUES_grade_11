from multiprocessing import Process
import os


def info(title):
    print(title)
    print('module name:', __name__)
    print('parent process:', os.getppid())
    print('process id:', os.getpid())


def factorial(n):
    rc = 0

    if n < 1:  # base case
        rc = 1
    else:
        return_number = n * factorial(n - 1)  # recursive call
        print("{} != {}".format(str(n), str(return_number)))
        rc = return_number

    return rc


if __name__ == '__main__':
    info('main line')
    p = Process(target=factorial, args=(10,))
    p.start()
    p.join()
