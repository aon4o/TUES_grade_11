# Python multithreading example to demonstrate locking.
# 1. Define a subclass using threading.Thread class.
# 2. Instantiate the subclass and trigger the thread.
# 3. Implement locks in thread's run method.

import threading
import datetime

exitFlag = 0


class Writer(threading.Thread):
    def __init__(self, name, counter):
        threading.Thread.__init__(self)
        self.threadID = counter
        self.name = name
        self.counter = counter

    def run(self):
        print("Starting {}[{}]".format(self.name, self.counter))
        # Acquire lock to synchronize thread
        thread_lock.acquire()
        i = 0
        while i < 150:
            resource.append(i)
            print("Writer {}".format(i))
            i += 1

        # Release lock for the next thread
        thread_lock.release()
        print("Exiting {}[{}]".format(self.name, self.counter))


class Reader(threading.Thread):
    def __init__(self, name, counter):
        threading.Thread.__init__(self)
        self.threadID = counter
        self.name = name
        self.counter = counter

    def run(self):
        print("Starting {}[{}]".format(self.name, self.counter))
        # Acquire lock to synchronize thread
        thread_lock.acquire()
        i = 0
        while i < 150:
            print("Reader {}".format(resource.pop()))
            i += 1

        # Release lock for the next thread
        thread_lock.release()
        print("Exiting {}[{}]".format(self.name, self.counter))


thread_lock = threading.Lock()
threads = []

resource = []

# Create new threads
thread1 = Writer("Thread", 1)
thread2 = Reader("Thread", 2)

# Start new Threads
thread1.start()
thread2.start()

# Add threads to thread list
threads.append(thread1)
threads.append(thread2)

# Wait for all threads to complete
for thread in threads:
    thread.join()

print("\nExiting the Program!!!")
